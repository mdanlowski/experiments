// Blueprint for bullets that the Player shoots out

function PlayerProjectile(x_, y_, vel_){
	
}